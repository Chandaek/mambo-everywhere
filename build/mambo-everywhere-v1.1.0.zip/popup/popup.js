"use strict";
(() => {
  // src/config.ts
  var config = {
    interactiveElement: {
      button: {
        label: "Buttons",
        selector: "button"
      },
      link: {
        label: "Links",
        selector: "a[href]"
      },
      area: {
        label: "Image map links",
        selector: "area[href]"
      },
      input: {
        label: "Input fields",
        selector: "input:not([type='hidden'])"
      },
      select: {
        label: "Select menus",
        selector: "select"
      },
      textarea: {
        label: "Text areas",
        selector: "textarea"
      },
      summary: {
        label: "Disclosure controls",
        selector: "summary"
      },
      label: {
        label: "Labels",
        selector: "label"
      },
      roleButton: {
        label: "Role: Button",
        selector: "[role='button']"
      },
      roleLink: {
        label: "Role: Link",
        selector: "[role='link']"
      },
      roleCheckbox: {
        label: "Role: Checkbox",
        selector: "[role='checkbox']"
      },
      roleRadio: {
        label: "Role: Radio",
        selector: "[role='radio']"
      },
      roleSwitch: {
        label: "Role: Switch",
        selector: "[role='switch']"
      },
      roleTab: {
        label: "Role: Tab",
        selector: "[role='tab']"
      },
      roleMenuitem: {
        label: "Role: Menu item",
        selector: "[role='menuitem']"
      },
      roleMenuitemcheckbox: {
        label: "Role: Menu item checkbox",
        selector: "[role='menuitemcheckbox']"
      },
      roleMenuitemradio: {
        label: "Role: Menu item radio",
        selector: "[role='menuitemradio']"
      },
      roleOption: {
        label: "Role: Option",
        selector: "[role='option']"
      },
      roleTreeitem: {
        label: "Role: Tree item",
        selector: "[role='treeitem']"
      },
      roleSlider: {
        label: "Role: Slider",
        selector: "[role='slider']"
      },
      roleSpinbutton: {
        label: "Role: Spin button",
        selector: "[role='spinbutton']"
      },
      roleCombobox: {
        label: "Role: Combo box",
        selector: "[role='combobox']"
      },
      roleListbox: {
        label: "Role: List box",
        selector: "[role='listbox']"
      },
      onclick: {
        label: "Custom onclick elements",
        selector: "[onclick]"
      }
    }
  };

  // src/settings.ts
  var defaultSettings = {
    interactiveElement: Object.fromEntries(
      Object.keys(config.interactiveElement).map((key) => [key, true])
    ),
    volume: 1
  };
  async function getSettings() {
    const result = await chrome.storage.local.get("settings");
    const stored = result["settings"];
    const interactiveElement = { ...defaultSettings.interactiveElement };
    for (const key of Object.keys(
      config.interactiveElement
    )) {
      const value = stored?.interactiveElement?.[key];
      if (typeof value === "boolean") {
        interactiveElement[key] = value;
      }
    }
    const volume = stored?.volume;
    return {
      interactiveElement,
      volume: typeof volume === "number" ? Math.min(1, Math.max(0, volume)) : defaultSettings.volume
    };
  }

  // src/statistics.ts
  var defaultStatistics = {
    totalPlays: 0,
    lastPlayedAt: null
  };
  async function getStatistics() {
    const result = await chrome.storage.local.get("statistics");
    const stored = result["statistics"];
    return {
      totalPlays: typeof stored?.totalPlays === "number" ? stored.totalPlays : 0,
      lastPlayedAt: typeof stored?.lastPlayedAt === "number" ? stored.lastPlayedAt : null
    };
  }
  async function resetStatistics() {
    await chrome.storage.local.set({
      statistics: defaultStatistics
    });
  }

  // src/popup/popup.ts
  var elementContainer = document.querySelector(
    "#interactive-elements"
  );
  var volumeInput = document.querySelector("#volume");
  var volumeValue = document.querySelector("#volume-value");
  var totalPlays = document.querySelector("#total-plays");
  var lastPlayed = document.querySelector("#last-played");
  var resetButton = document.querySelector("#reset-statistics");
  var settings;
  async function saveSettings() {
    await chrome.storage.local.set({ settings });
  }
  function createInteractiveElementSettings() {
    if (!elementContainer) {
      return;
    }
    elementContainer.replaceChildren();
    for (const key of Object.keys(
      config.interactiveElement
    )) {
      const element = config.interactiveElement[key];
      const row = document.createElement("label");
      row.className = "setting-row";
      const name = document.createElement("span");
      name.textContent = element.label;
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = settings.interactiveElement[key];
      checkbox.addEventListener("change", () => {
        settings.interactiveElement[key] = checkbox.checked;
        void saveSettings();
      });
      row.append(name, checkbox);
      elementContainer.append(row);
    }
  }
  function initializeVolume() {
    if (!volumeInput || !volumeValue) {
      return;
    }
    volumeInput.value = String(Math.round(settings.volume * 100));
    volumeValue.value = `${volumeInput.value}%`;
    volumeInput.addEventListener("input", () => {
      if (!volumeInput || !volumeValue) {
        return;
      }
      volumeValue.value = `${volumeInput.value}%`;
    });
    volumeInput.addEventListener("change", () => {
      if (!volumeInput) {
        return;
      }
      settings.volume = Number(volumeInput.value) / 100;
      void saveSettings();
    });
  }
  async function updateStatistics() {
    const statistics = await getStatistics();
    if (totalPlays) {
      totalPlays.textContent = String(statistics.totalPlays);
    }
    if (lastPlayed) {
      lastPlayed.textContent = statistics.lastPlayedAt ? new Date(statistics.lastPlayedAt).toLocaleString() : "Never";
    }
  }
  function initializeStatistics() {
    resetButton?.addEventListener("click", async () => {
      await resetStatistics();
      await updateStatistics();
    });
  }
  async function initialize() {
    settings = await getSettings();
    createInteractiveElementSettings();
    initializeVolume();
    initializeStatistics();
    await updateStatistics();
  }
  void initialize();
})();
