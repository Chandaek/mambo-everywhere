"use strict";
(() => {
  // src/config.ts
  var config = {
    interactiveElement: {
      button: {
        label: "Buttons",
        selector: "button"
      },
      link: {
        label: "Links",
        selector: "a[href]"
      },
      area: {
        label: "Image map links",
        selector: "area[href]"
      },
      input: {
        label: "Input fields",
        selector: "input:not([type='hidden'])"
      },
      select: {
        label: "Select menus",
        selector: "select"
      },
      textarea: {
        label: "Text areas",
        selector: "textarea"
      },
      summary: {
        label: "Disclosure controls",
        selector: "summary"
      },
      label: {
        label: "Labels",
        selector: "label"
      },
      roleButton: {
        label: "Role: Button",
        selector: "[role='button']"
      },
      roleLink: {
        label: "Role: Link",
        selector: "[role='link']"
      },
      roleCheckbox: {
        label: "Role: Checkbox",
        selector: "[role='checkbox']"
      },
      roleRadio: {
        label: "Role: Radio",
        selector: "[role='radio']"
      },
      roleSwitch: {
        label: "Role: Switch",
        selector: "[role='switch']"
      },
      roleTab: {
        label: "Role: Tab",
        selector: "[role='tab']"
      },
      roleMenuitem: {
        label: "Role: Menu item",
        selector: "[role='menuitem']"
      },
      roleMenuitemcheckbox: {
        label: "Role: Menu item checkbox",
        selector: "[role='menuitemcheckbox']"
      },
      roleMenuitemradio: {
        label: "Role: Menu item radio",
        selector: "[role='menuitemradio']"
      },
      roleOption: {
        label: "Role: Option",
        selector: "[role='option']"
      },
      roleTreeitem: {
        label: "Role: Tree item",
        selector: "[role='treeitem']"
      },
      roleSlider: {
        label: "Role: Slider",
        selector: "[role='slider']"
      },
      roleSpinbutton: {
        label: "Role: Spin button",
        selector: "[role='spinbutton']"
      },
      roleCombobox: {
        label: "Role: Combo box",
        selector: "[role='combobox']"
      },
      roleListbox: {
        label: "Role: List box",
        selector: "[role='listbox']"
      },
      onclick: {
        label: "Custom onclick elements",
        selector: "[onclick]"
      }
    }
  };

  // src/settings.ts
  var defaultSettings = {
    interactiveElement: Object.fromEntries(
      Object.keys(config.interactiveElement).map((key) => [key, true])
    ),
    volume: 1
  };
  async function getSettings() {
    const result = await chrome.storage.local.get("settings");
    const stored = result["settings"];
    const interactiveElement = { ...defaultSettings.interactiveElement };
    for (const key of Object.keys(
      config.interactiveElement
    )) {
      const value = stored?.interactiveElement?.[key];
      if (typeof value === "boolean") {
        interactiveElement[key] = value;
      }
    }
    const volume = stored?.volume;
    return {
      interactiveElement,
      volume: typeof volume === "number" ? Math.min(1, Math.max(0, volume)) : defaultSettings.volume
    };
  }

  // src/statistics.ts
  async function getStatistics() {
    const result = await chrome.storage.local.get("statistics");
    const stored = result["statistics"];
    return {
      totalPlays: typeof stored?.totalPlays === "number" ? stored.totalPlays : 0,
      lastPlayedAt: typeof stored?.lastPlayedAt === "number" ? stored.lastPlayedAt : null
    };
  }
  async function recordPlayback() {
    const statistics = await getStatistics();
    await chrome.storage.local.set({
      statistics: {
        totalPlays: statistics.totalPlays + 1,
        lastPlayedAt: Date.now()
      }
    });
  }

  // src/audio.ts
  var audio = new Audio(chrome.runtime.getURL("assets/audio/mambo.mp3"));
  var context = new AudioContext();
  var source = context.createMediaElementSource(audio);
  var gain = context.createGain();
  source.connect(gain);
  gain.connect(context.destination);
  async function playAudio(options = {}) {
    await context.resume();
    audio.pause();
    audio.currentTime = 0;
    gain.gain.value = options.volume ?? 1;
    audio.playbackRate = options.playbackRate ?? 1;
    audio.preservesPitch = false;
    await audio.play();
  }

  // src/content.ts
  var settings;
  function getInteractiveSelector() {
    return Object.keys(config.interactiveElement).filter((key) => settings.interactiveElement[key]).map((key) => config.interactiveElement[key].selector).join(", ");
  }
  function handleClick(event) {
    const target = event.target;
    if (!(target instanceof Element)) {
      return;
    }
    const selector = getInteractiveSelector();
    if (!selector) {
      return;
    }
    const element = target.closest(selector);
    if (!element || element.matches(":disabled, [aria-disabled='true']")) {
      return;
    }
    void playAudio({ volume: settings.volume }).then(recordPlayback).catch(() => void 0);
  }
  async function initialize() {
    settings = await getSettings();
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !changes["settings"]) {
        return;
      }
      void getSettings().then((value) => {
        settings = value;
      });
    });
    document.addEventListener("click", handleClick);
  }
  void initialize();
})();
