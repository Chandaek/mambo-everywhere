"use strict";
(() => {
  // src/audio.ts
  var audio = new Audio(chrome.runtime.getURL("assets/audio/mambo.mp3"));
  var context = new AudioContext();
  var source = context.createMediaElementSource(audio);
  var gain = context.createGain();
  source.connect(gain);
  gain.connect(context.destination);
  async function playAudio(options = {}) {
    await context.resume();
    audio.pause();
    audio.currentTime = 0;
    gain.gain.value = options.volume ?? 1;
    audio.playbackRate = options.playbackRate ?? 1;
    audio.preservesPitch = false;
    await audio.play();
  }

  // src/content.ts
  function initialize() {
    document.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      const button = target.closest(
        'button, input[type="button"], input[type="submit"], [role="button"]'
      );
      if (!button) {
        return;
      }
      void playAudio();
    });
  }
  initialize();
})();
